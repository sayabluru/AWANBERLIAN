# WINRDP BA_channel

build yml :https://pastebin.com/MBVNQp2G

Remotedesktop chrome : https://remotedesktop.google.com/headless

tutorial yt Bang Android
Watch Video: https://youtu.be/HXCjo8Ky3RA

# Selamat Mencoba Dan Semoga Berkah Teman Teman
